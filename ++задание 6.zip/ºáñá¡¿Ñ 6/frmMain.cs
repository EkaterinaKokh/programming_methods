﻿using Microsoft.Office.Interop.Excel;
using System;
using System.IO;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace задание_6
{
    public partial class frmMain : Form
    {
        Excel.Application excelApp;
        Excel.Workbook workbook;
        Excel.Worksheet worksheet;
        public frmMain()
        {
            InitializeComponent();
        }
        private void btnLoadToExcel_Click(object sender, EventArgs e)
        {
            excelApp = new Excel.Application();
            workbook = excelApp.Workbooks.Add();
            worksheet = workbook.Sheets[1];

            Excel.Range rangeA16 = worksheet.get_Range("A1", "A6");
            rangeA16.Merge();
            Excel.Range cellA16 = worksheet.get_Range("A1", "A6");
            cellA16.Value = "№п/п";
            cellA16.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThick, XlColorIndex.xlColorIndexAutomatic);


            Excel.Range rangeB16 = worksheet.get_Range("B1", "B6");
            rangeB16.Merge();
            Excel.Range cellB16 = worksheet.get_Range("B1", "B6");
            cellB16.Value = "Наименование работ\n";
            cellB16.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThick, XlColorIndex.xlColorIndexAutomatic);

            Excel.Range rangeC16 = worksheet.get_Range("C1", "C6");
            rangeC16.Merge();
            Excel.Range cellC16 = worksheet.get_Range("C1", "C6");
            cellC16.Value = "Обоснование по СНиП и ЕНиР\n";
            cellC16.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThick, XlColorIndex.xlColorIndexAutomatic);

            Excel.Range rangeDE = worksheet.get_Range("D1", "E4");
            rangeDE.Merge();
            Excel.Range cellDE = worksheet.get_Range("D1", "E4");
            cellDE.Value = "Объём работ";
            cellDE.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThick, XlColorIndex.xlColorIndexAutomatic);

            Excel.Range rangeD56 = worksheet.get_Range("D5", "D6");
            rangeD56.Merge();
            Excel.Range cellD56 = worksheet.get_Range("D5", "D6");
            cellD56.Value = "Ед. измерения\n";
            cellD56.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThick, XlColorIndex.xlColorIndexAutomatic);

            Excel.Range rangeE56 = worksheet.get_Range("E5", "E6");
            rangeE56.Merge();
            Excel.Range cellE56 = worksheet.get_Range("E5", "E6");
            cellE56.Value = "Кол-во";
            cellE56.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThick, XlColorIndex.xlColorIndexAutomatic);

            Excel.Range rangeF16 = worksheet.get_Range("F1", "F6");
            rangeF16.Merge();
            Excel.Range cellF16 = worksheet.get_Range("F1", "F6");
            cellF16.Value = "Норма на ед. в чел. -час\n";
            cellF16.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThick, XlColorIndex.xlColorIndexAutomatic);

            Excel.Range rangeGH1 = worksheet.get_Range("G1", "H2");
            rangeGH1.Merge();
            Excel.Range cellGH1 = worksheet.get_Range("G1", "H2");
            cellGH1.Value = "Трудоемкость";
            cellGH1.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThick, XlColorIndex.xlColorIndexAutomatic);

            Excel.Range rangeGH2 = worksheet.get_Range("G3", "H4");
            rangeGH2.Merge();
            Excel.Range cellGH2 = worksheet.get_Range("G3", "H4");
            cellGH2.Value = "Потребное кол-во на весь объем\n";
            cellGH2.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThick, XlColorIndex.xlColorIndexAutomatic);

            Excel.Range rangeG56 = worksheet.get_Range("G5", "G6");
            rangeG56.Merge();
            Excel.Range cellG56 = worksheet.get_Range("G5", "G6");
            cellG56.Value = "Чел.- час\n";
            cellG56.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThick, XlColorIndex.xlColorIndexAutomatic);

            Excel.Range rangeH56 = worksheet.get_Range("H5", "H6");
            rangeH56.Merge();
            Excel.Range cellH56 = worksheet.get_Range("H5", "H6");
            cellH56.Value = "Чел.- дн.\n";
            cellH56.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThick, XlColorIndex.xlColorIndexAutomatic);

            Excel.Range rangeIK = worksheet.get_Range("I1", "K2");
            rangeIK.Merge();
            Excel.Range cellIK = worksheet.get_Range("I1", "K2");
            cellIK.Value = "Затраты машинного времени\n";
            cellIK.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThick, XlColorIndex.xlColorIndexAutomatic);

            Excel.Range rangeI36 = worksheet.get_Range("I3", "I6");
            rangeI36.Merge();
            Excel.Range cellI36 = worksheet.get_Range("I3", "I6");
            cellI36.Value = "Норма на ед. маш.- час\n";
            cellI36.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThick, XlColorIndex.xlColorIndexAutomatic);

            Excel.Range rangeJ36 = worksheet.get_Range("J3", "J6");
            rangeJ36.Merge();
            Excel.Range cellJ36 = worksheet.get_Range("J3", "J6");
            cellJ36.Value = "Маш. -час\n";
            cellJ36.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThick, XlColorIndex.xlColorIndexAutomatic);

            Excel.Range rangeK36 = worksheet.get_Range("K3", "K6");
            rangeK36.Merge();
            Excel.Range cellK36 = worksheet.get_Range("K3", "K6");
            cellK36.Value = "Маш.- см.\n";
            cellK36.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThick, XlColorIndex.xlColorIndexAutomatic);

            Excel.Range rangeL16 = worksheet.get_Range("L1", "L6");
            rangeL16.Merge();
            Excel.Range cellL16 = worksheet.get_Range("L1", "L6");
            cellL16.Value = "Конструкции, изделия, материалы\n";
            cellL16.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThick, XlColorIndex.xlColorIndexAutomatic);

            Excel.Range rangeM16 = worksheet.get_Range("M1", "M6");
            rangeM16.Merge();
            Excel.Range cellM16 = worksheet.get_Range("M1", "M6");
            cellM16.Value = "Норма на ед. объема\n";
            cellM16.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThick, XlColorIndex.xlColorIndexAutomatic);

            Excel.Range rangeN16 = worksheet.get_Range("N1", "N6");
            rangeN16.Merge();
            Excel.Range cellN16 = worksheet.get_Range("N1", "N6");
            cellN16.Value = "Потребность на весь объем\n";
            cellN16.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThick, XlColorIndex.xlColorIndexAutomatic);

            Excel.Range cellA7 = worksheet.get_Range("A7", "A7");
            cellA7.Value = "1";
            

            Excel.Range cellB7 = worksheet.get_Range("B7", "B7");
            cellB7.Value = "2";
            

            Excel.Range cellC7 = worksheet.get_Range("C7", "C7");
            cellC7.Value = "3";
            

            Excel.Range cellD7 = worksheet.get_Range("D7", "D7");
            cellD7.Value = "4";
            

            Excel.Range cellE7 = worksheet.get_Range("E7", "E7");
            cellE7.Value = "5";
            

            Excel.Range cellF7 = worksheet.get_Range("F7", "F7");
            cellF7.Value = "6";
            

            Excel.Range cellG7 = worksheet.get_Range("G7", "G7");
            cellG7.Value = "7";
            

            Excel.Range cellH7 = worksheet.get_Range("H7", "H7");
            cellH7.Value = "8";
            

            Excel.Range cellI7 = worksheet.get_Range("I7", "I7");
            cellI7.Value = "9";
            

            Excel.Range cellJ7 = worksheet.get_Range("J7", "J7");
            cellJ7.Value = "10";
            

            Excel.Range cellK7 = worksheet.get_Range("K7", "K7");
            cellK7.Value = "11";
            

            Excel.Range cellL7 = worksheet.get_Range("L7", "L7");
            cellL7.Value = "12";
            

            Excel.Range cellM7 = worksheet.get_Range("M7", "M7");
            cellM7.Value = "13";
            

            Excel.Range cellN7 = worksheet.get_Range("N7", "N7");
            cellN7.Value = "14";
            

            foreach (Excel.Range cell in worksheet.get_Range("A1", "N14").Cells)
            {
                cell.Interior.Color = XlRgbColor.rgbBeige; 
                cell.WrapText = true;
                cell.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                cell.VerticalAlignment = Excel.XlVAlign.xlVAlignTop;
                cell.BorderAround(Excel.XlLineStyle.xlContinuous, Excel.XlBorderWeight.xlThick, XlColorIndex.xlColorIndexAutomatic);
            }

            excelApp.Visible = true;

        }
        private void btnPreview_Click(object sender, EventArgs e)
        {
            Form frmPreview = new Form();
            frmPreview.Text = "Предпросмотр таблицы";
            frmPreview.WindowState = FormWindowState.Maximized;

            DataGridView dataGridView = new DataGridView();
            dataGridView.Dock = DockStyle.Fill; 
            frmPreview.Controls.Add(dataGridView);

            dataGridView.Columns.Add("№п/п", "№п/п");
            dataGridView.Columns.Add("Наименование работ\n", "Наименование работ\n");
            dataGridView.Columns.Add("Обоснование по СНиП и ЕНиР\n", "Обоснование по СНиП и ЕНиР\n");
            dataGridView.Columns.Add("Объём работ", "Объём работ");
            dataGridView.Columns.Add("", "");
            dataGridView.Columns.Add("Норма на ед. в чел. -час\n", "Норма на ед. в чел. -час\n");
            dataGridView.Columns.Add("Трудоемкость\n", "Трудоемкость\n");
            dataGridView.Columns.Add("", "");
            dataGridView.Columns.Add("Затраты машинного времени\n", "Затраты машинного времени\n");
            dataGridView.Columns.Add("", "");
            dataGridView.Columns.Add("", "");
            dataGridView.Columns.Add("Конструкции, изделия, материалы\n", "Конструкции, изделия, материалы\n");
            dataGridView.Columns.Add("Норма на ед. объема\n", "Норма на ед. объема\n");
            dataGridView.Columns.Add("Потребность на весь объем\n", "Потребность на весь объем\n");

            dataGridView.ColumnHeadersHeight = 60;

            dataGridView.Rows.Add("", "", "", "", "", "", "Потребное кол-во на весь объем", "", "","", "", "", "", "");
            dataGridView.Rows.Add("", "", "", "Ед.измерения", "Кол-во", "", "Чел.- час", "Чел.- дн.", "Норма на ед. маш.- час", "Маш. -час", "Маш. -см.", "", "", "");
            dataGridView.Rows.Add();
            dataGridView.Rows.Add();
            dataGridView.Rows.Add();
            dataGridView.Rows.Add();
            dataGridView.Rows.Add();
            dataGridView.Rows.Add();
            dataGridView.Rows.Add();
            dataGridView.Rows.Add();
            dataGridView.Rows.Add();

            int columnIndex = 6; 
            dataGridView.Columns[columnIndex].Width = 190;

            int columnIndex1 = 0;
            dataGridView.Columns[columnIndex1].Width = 40;

            int columnIndex2 = 8;
            dataGridView.Columns[columnIndex2].Width = 150;
            dataGridView.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            frmPreview.ShowDialog();
        }
         private void btnFillWithData_Click(object sender, EventArgs e)
        {
            if (worksheet == null)
            {
                MessageBox.Show("Сначала создайте таблицу Excel, нажав на кнопку 'Выгрузка в Excel'.");
                return;
            }

            try
            {
                using (StreamReader sr = new StreamReader("data.txt"))
                {
                    int row = 8;
                    int col = 1;

                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        string[] values = line.Split(';');
                        foreach (string value in values)
                        {
                            Excel.Range cell = worksheet.Cells[row, col];
                            cell.Value = value.Trim();


                            cell.HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter;
                            cell.VerticalAlignment = Excel.XlVAlign.xlVAlignTop;

                            col++;
                        }
                        row++;
                        col = 1;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при чтении файла: " + ex.Message);
            }

        }
    }
}