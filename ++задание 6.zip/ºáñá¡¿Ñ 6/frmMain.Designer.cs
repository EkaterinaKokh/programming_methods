﻿namespace задание_6
{
    partial class frmMain
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLoadToExcel = new System.Windows.Forms.Button();
            this.btnFillWithData = new System.Windows.Forms.Button();
            this.btnPreview = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnLoadToExcel
            // 
            this.btnLoadToExcel.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnLoadToExcel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnLoadToExcel.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLoadToExcel.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnLoadToExcel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnLoadToExcel.Location = new System.Drawing.Point(297, 107);
            this.btnLoadToExcel.Name = "btnLoadToExcel";
            this.btnLoadToExcel.Size = new System.Drawing.Size(212, 40);
            this.btnLoadToExcel.TabIndex = 0;
            this.btnLoadToExcel.Text = "Выгрузка в Excel";
            this.btnLoadToExcel.UseVisualStyleBackColor = false;
            this.btnLoadToExcel.Click += new System.EventHandler(this.btnLoadToExcel_Click);
            // 
            // btnFillWithData
            // 
            this.btnFillWithData.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnFillWithData.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFillWithData.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnFillWithData.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnFillWithData.Location = new System.Drawing.Point(297, 178);
            this.btnFillWithData.Name = "btnFillWithData";
            this.btnFillWithData.Size = new System.Drawing.Size(212, 40);
            this.btnFillWithData.TabIndex = 1;
            this.btnFillWithData.Text = "Заполнение данными";
            this.btnFillWithData.UseVisualStyleBackColor = false;
            this.btnFillWithData.Click += new System.EventHandler(this.btnFillWithData_Click);
            // 
            // btnPreview
            // 
            this.btnPreview.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnPreview.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPreview.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnPreview.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnPreview.Location = new System.Drawing.Point(297, 250);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(212, 40);
            this.btnPreview.TabIndex = 2;
            this.btnPreview.Text = "Предпросмотр";
            this.btnPreview.UseVisualStyleBackColor = false;
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnPreview);
            this.Controls.Add(this.btnFillWithData);
            this.Controls.Add(this.btnLoadToExcel);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "frmMain";
            this.Text = "Задание №6 выполнили: Кох Е.Е.,Папошина Л.С.,Насонова А.Н.; Номер варианта: 10; Д" +
    "ата выполнения: 12/05/2024";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnLoadToExcel;
        private System.Windows.Forms.Button btnFillWithData;
        private System.Windows.Forms.Button btnPreview;
    }
}

