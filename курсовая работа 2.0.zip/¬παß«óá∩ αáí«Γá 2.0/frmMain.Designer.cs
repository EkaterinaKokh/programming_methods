﻿using System;

namespace курсовая_работа_2._0
{
    partial class frmMain
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.cBWord = new System.Windows.Forms.ComboBox();
            this.btnCSV = new System.Windows.Forms.Button();
            this.btnPreview = new System.Windows.Forms.Button();
            this.btnExcel = new System.Windows.Forms.Button();
            this.btnRecovery = new System.Windows.Forms.Button();
            this.btnAnalysis = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cBWord
            // 
            this.cBWord.FormattingEnabled = true;
            this.cBWord.Location = new System.Drawing.Point(273, 38);
            this.cBWord.Name = "cBWord";
            this.cBWord.Size = new System.Drawing.Size(257, 24);
            this.cBWord.TabIndex = 0;
            this.cBWord.SelectedIndexChanged += new System.EventHandler(this.cBWord_SelectedIndexChanged);
            // 
            // btnCSV
            // 
            this.btnCSV.Location = new System.Drawing.Point(35, 38);
            this.btnCSV.Name = "btnCSV";
            this.btnCSV.Size = new System.Drawing.Size(159, 47);
            this.btnCSV.TabIndex = 1;
            this.btnCSV.Text = "Преобразование в CSV";
            this.btnCSV.UseVisualStyleBackColor = true;
            this.btnCSV.Click += new System.EventHandler(this.btnCSV_Click);
            // 
            // btnPreview
            // 
            this.btnPreview.Location = new System.Drawing.Point(35, 121);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(159, 58);
            this.btnPreview.TabIndex = 2;
            this.btnPreview.Text = "Предпросмотр печатной формы";
            this.btnPreview.UseVisualStyleBackColor = true;
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // btnExcel
            // 
            this.btnExcel.Location = new System.Drawing.Point(35, 219);
            this.btnExcel.Name = "btnExcel";
            this.btnExcel.Size = new System.Drawing.Size(159, 56);
            this.btnExcel.TabIndex = 3;
            this.btnExcel.Text = "Преобразование Word в Excel";
            this.btnExcel.UseVisualStyleBackColor = true;
            this.btnExcel.Click += new System.EventHandler(this.btnExcel_Click);
            // 
            // btnRecovery
            // 
            this.btnRecovery.Location = new System.Drawing.Point(35, 310);
            this.btnRecovery.Name = "btnRecovery";
            this.btnRecovery.Size = new System.Drawing.Size(159, 58);
            this.btnRecovery.TabIndex = 4;
            this.btnRecovery.Text = "Восстановить печатную форму";
            this.btnRecovery.UseVisualStyleBackColor = true;
            this.btnRecovery.Click += new System.EventHandler(this.btnRecovery_Click);
            // 
            // btnAnalysis
            // 
            this.btnAnalysis.Location = new System.Drawing.Point(610, 38);
            this.btnAnalysis.Name = "btnAnalysis";
            this.btnAnalysis.Size = new System.Drawing.Size(159, 46);
            this.btnAnalysis.TabIndex = 5;
            this.btnAnalysis.Text = "Анализ данных";
            this.btnAnalysis.UseVisualStyleBackColor = true;
            this.btnAnalysis.Click += new System.EventHandler(this.btnAnalysis_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnAnalysis);
            this.Controls.Add(this.btnRecovery);
            this.Controls.Add(this.btnExcel);
            this.Controls.Add(this.btnPreview);
            this.Controls.Add(this.btnCSV);
            this.Controls.Add(this.cBWord);
            this.Name = "frmMain";
            this.Text = "Курсовая работа";
            this.ResumeLayout(false);

        }

        private void cBWord_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        #endregion

        private System.Windows.Forms.ComboBox cBWord;
        private System.Windows.Forms.Button btnCSV;
        private System.Windows.Forms.Button btnPreview;
        private System.Windows.Forms.Button btnExcel;
        private System.Windows.Forms.Button btnRecovery;
        private System.Windows.Forms.Button btnAnalysis;
    }
}

