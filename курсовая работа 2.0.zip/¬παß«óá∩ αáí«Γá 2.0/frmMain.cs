﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using System.Windows.Forms.DataVisualization.Charting;

namespace курсовая_работа_2._0
{

    public partial class frmMain : Form
    {
        DataGridView dataGridView;
        private string csvFilePath;
        private Form frmAnalysis;
        private Form frmSpravka;

        public frmMain()
        {
            InitializeComponent();

            string printedForms = Path.Combine(Environment.CurrentDirectory, "печатные формы");

            if (Directory.Exists(printedForms))
            {
                string[] filesWord = Directory.GetFiles(printedForms, "*.docx");

                foreach (string file in filesWord)
                {
                    string nameFile = Path.GetFileNameWithoutExtension(file);
                    cBWord.Items.Add(nameFile);
                }
            }
            else
            {
                MessageBox.Show("Папка 'печатные формы' не найдена.", "Ошибка");
            }

        }

        private void btnCSV_Click(object sender, EventArgs e)
        {
            if (cBWord.SelectedItem != null)
            {
                string selectedFile = Path.Combine(Environment.CurrentDirectory, "печатные формы", $"{cBWord.SelectedItem}.docx");

                if (File.Exists(selectedFile))
                {
                    ConvertWordToCSV(selectedFile);

                    MessageBox.Show($"Файл успешно сохранен в папке csv как {cBWord.SelectedItem}.csv", "Успех");
                }
                else
                {
                    MessageBox.Show("Выбранный файл Word не найден.", "Ошибка");
                }
            }
            else
            {
                MessageBox.Show("Выберите файл Word для преобразования в формат csv.", "Предупреждение");
            }
        }

        private void ConvertWordToCSV(string selectedFile)
        {
            try
            {
                using (WordprocessingDocument wordDocument = WordprocessingDocument.Open(selectedFile, true))
                {
                    MainDocumentPart mainPart = wordDocument.MainDocumentPart;
                    var tables = mainPart.Document.Descendants<DocumentFormat.OpenXml.Wordprocessing.Table>();

                    // Использование StringBuilder позволяет эффективно управлять изменением и объединением строк, особенно при работе с большими объемами данных.
                    StringBuilder csvBuilder = new StringBuilder();

                    foreach (var table in tables)
                    {
                        csvBuilder.AppendLine(string.Join("!", table.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableRow>().First().Descendants<DocumentFormat.OpenXml.Wordprocessing.TableCell>().Select(c => c.InnerText.Trim())));

                        foreach (var row in table.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableRow>().Skip(1))
                        {
                            csvBuilder.AppendLine(string.Join("!", row.Descendants<DocumentFormat.OpenXml.Wordprocessing.TableCell>().Select(c => c.InnerText.Trim())));
                        }

                        csvBuilder.AppendLine();
                    }

                    string folderCSV = Path.Combine(Environment.CurrentDirectory, "csv");
                    if (!Directory.Exists(folderCSV))
                    {
                        Directory.CreateDirectory(folderCSV);
                    }
                    csvFilePath = Path.Combine(folderCSV, $"{cBWord.SelectedItem}.csv");
                    File.WriteAllText(csvFilePath, csvBuilder.ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка при преобразовании файла: {ex.Message}", "Ошибка");
            }
        }

        private void btnPreview_Click(object sender, EventArgs e)
        {
            if (cBWord.SelectedItem != null)
            {
                if (!string.IsNullOrEmpty(csvFilePath))
                {
                    Form frmPreview = new Form();
                    dataGridView = new DataGridView();
                    dataGridView.Dock = DockStyle.Fill;
                    frmPreview.Controls.Add(dataGridView);
                    frmPreview.Show();

                    LoadCSVDataToDataGridView(csvFilePath);
                }
                else
                {
                    MessageBox.Show("Сначала необходимо преобразовать файл Word в CSV.", "Предупреждение");
                }
            }
            else
            {
                MessageBox.Show("Выберите файл Word для предпросмотра.", "Предупреждение");
            }
        }

        private void LoadCSVDataToDataGridView(string csvFilePath)
        {
            if (File.Exists(csvFilePath))
            {
                try
                {
                    System.Data.DataTable dataTable = new System.Data.DataTable();

                    string[] lines = File.ReadAllLines(csvFilePath);

                    if (lines.Length > 0)
                    {
                        string[] headers = lines[0].Split('!');
                        foreach (var header in headers)
                        {
                            dataTable.Columns.Add(header);
                        }

                        for (int i = 1; i < lines.Length; i++)
                        {
                            string[] values = lines[i].Split('!');
                            DataRow dataRow = dataTable.NewRow();
                            for (int j = 0; j < values.Length && j < dataTable.Columns.Count; j++)
                            {
                                dataRow[j] = values[j].Trim();
                            }
                            dataTable.Rows.Add(dataRow);
                        }

                        dataGridView.DataSource = dataTable;

                        dataGridView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;
                    }
                    else
                    {
                        MessageBox.Show("CSV файл пустой.", "Предупреждение");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Произошла ошибка при загрузке данных: {ex.Message}", "Ошибка");
                }
            }
            else
            {
                MessageBox.Show($"CSV файл не найден: {csvFilePath}", "Ошибка");
            }
        }

        private void btnExcel_Click(object sender, EventArgs e)
        {
            if (File.Exists(csvFilePath))
            {
                string folderExcel = Path.Combine(Environment.CurrentDirectory, "excel");
                if (!Directory.Exists(folderExcel))
                {
                    Directory.CreateDirectory(folderExcel);
                }

                string excelFilePath = Path.Combine(folderExcel, $"{cBWord.SelectedItem}.xlsx");

                System.Data.DataTable dataTable = new System.Data.DataTable();

                using (StreamReader reader = new StreamReader(csvFilePath))
                {
                    string headersLine = reader.ReadLine();
                    string[] headers = headersLine.Split('!');
                    foreach (string header in headers)
                    {
                        dataTable.Columns.Add(header);
                    }

                    dataTable.Rows.Add(headers);

                    while (!reader.EndOfStream)
                    {
                        string[] values = reader.ReadLine().Split('!');

                        if (values.Length > dataTable.Columns.Count)
                        {
                            for (int i = dataTable.Columns.Count; i < values.Length; i++)
                            {
                                dataTable.Columns.Add($"Столбец{i + 1}");
                            }
                        }
                        dataTable.Rows.Add(values);
                    }
                }

                using (var document = SpreadsheetDocument.Create(excelFilePath, SpreadsheetDocumentType.Workbook))
                {
                    var workbookPart = document.AddWorkbookPart();
                    workbookPart.Workbook = new Workbook();

                    var worksheetPart = workbookPart.AddNewPart<WorksheetPart>();
                    worksheetPart.Worksheet = new Worksheet();

                    var sheets = workbookPart.Workbook.AppendChild(new Sheets());
                    sheets.AppendChild(new Sheet()
                    {
                        Id = workbookPart.GetIdOfPart(worksheetPart),
                        SheetId = 1,
                        Name = "Лист1"
                    });

                    var sheetData = worksheetPart.Worksheet.AppendChild(new SheetData());

                    for (int i = 0; i < dataTable.Rows.Count; i++)
                    {
                        var row = sheetData.AppendChild(new Row());
                        for (int j = 0; j < dataTable.Columns.Count; j++)
                        {
                            var cell = row.AppendChild(new Cell());
                            cell.DataType = new EnumValue<CellValues>(CellValues.String);
                            cell.AppendChild(new CellValue($"{dataTable.Rows[i][j]}"));
                        }
                    }

                }

                MessageBox.Show($"Файл успешно сохранен в папке excel как {cBWord.SelectedItem}.xlsx", "Успех");
            }
            else
            {
                MessageBox.Show("Перед преобразованием в формат xlsx необходимо сгенерировать файл csv.", "Предупреждение");
            }
        }

        private void btnRecovery_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(csvFilePath))
            {
                try
                {
                    string[] lines = File.ReadAllLines(csvFilePath);
                    string wordFilePath = Path.Combine(Directory.GetCurrentDirectory(), "word", $"{cBWord.SelectedItem}.docx");

                    using (WordprocessingDocument wordDocument = WordprocessingDocument.Create(wordFilePath, WordprocessingDocumentType.Document))
                    {
                        MainDocumentPart mainPart = wordDocument.AddMainDocumentPart();
                        mainPart.Document = new Document();
                        Body body = new Body();
                        DocumentFormat.OpenXml.Wordprocessing.Table table = new DocumentFormat.OpenXml.Wordprocessing.Table();

                        table.AppendChild(new TableProperties(
                            new TableBorders(
                                //Использование EnumValue позволяет установить значение перечисления BorderValues для каждой границы (верхней, нижней, левой, правой, внутренних горизонтальных и вертикальных) в формате Open XML для документов Word. В данном контексте EnumValue помогает явно указать тип значения перечисления для каждой границы и установить ее размер равным 6.
                                new DocumentFormat.OpenXml.Wordprocessing.TopBorder() { Val = new EnumValue<BorderValues>(BorderValues.Single), Size = 6 }, 
                                new DocumentFormat.OpenXml.Wordprocessing.BottomBorder() { Val = new EnumValue<BorderValues>(BorderValues.Single), Size = 6 }, 
                                new DocumentFormat.OpenXml.Wordprocessing.LeftBorder() { Val = new EnumValue<BorderValues>(BorderValues.Single), Size = 6 }, 
                                new DocumentFormat.OpenXml.Wordprocessing.RightBorder() { Val = new EnumValue<BorderValues>(BorderValues.Single), Size = 6 }, 
                                new InsideVerticalBorder() { Val = new EnumValue<BorderValues>(BorderValues.Single), Size = 6 }
                            )
                        ));

                        foreach (var line in lines)
                        {
                            if (!string.IsNullOrEmpty(line))
                            {
                                TableRow row = new TableRow();
                                string[] values = line.Split('!'); int currentColumnsCount = 0;
                                foreach (var value in values)
                                {
                                    TableCell cell = new TableCell(new Paragraph(new DocumentFormat.OpenXml.Wordprocessing.Run(new DocumentFormat.OpenXml.Wordprocessing.Text(value))));
                                    row.Append(cell);
                                    currentColumnsCount++;
                                }

                                while (currentColumnsCount < row.ChildElements.Count)
                                {
                                    row.Append(new TableCell(new Paragraph(new DocumentFormat.OpenXml.Wordprocessing.Run())));
                                    currentColumnsCount++;
                                }

                                table.Append(row);
                            }
                        }

                        body.Append(table);
                        mainPart.Document.Append(body);
                    }

                    MessageBox.Show($"Файл успешно сохранен в папке word как {cBWord.SelectedItem}.docx", "Успех");
                }
               
                catch (Exception ex)
                {
                    MessageBox.Show($"Произошла ошибка при восстановлении файла: {ex.Message}", "Ошибка");
                }
            }
            else
            {
                MessageBox.Show("Сначала преобразуйте файл Word в CSV.", "Предупреждение");
            }
        }

        private void btnAnalysis_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(csvFilePath))
            {
                frmAnalysis = new Form(); // Создаем форму frmAnalysis
                frmAnalysis.Text = "Анализ данных";
                frmAnalysis.Size = new Size(800, 700);

                Button btnPopulAll = new Button();
                btnPopulAll.Text = "Построить диаграмму 'Популярность заявок на аудитории всех упомянутых преподавателей'";
                btnPopulAll.Size = new Size(150, 90);
                btnPopulAll.Location = new Point(30, 10);
                btnPopulAll.Click += new EventHandler(btnPopulAll_Click);
                frmAnalysis.Controls.Add(btnPopulAll);

                Button btnPopul = new Button();
                btnPopul.Text = "Построить диаграмму 'Популярность заявок на аудитории первых из упомянутых преподавателей'";
                btnPopul.Size = new Size(150, 90);
                btnPopul.Location = new Point(220, 10);
                btnPopul.Click += new EventHandler(btnPopul_Click);
                frmAnalysis.Controls.Add(btnPopul);

                TextBox txtTeacher = new TextBox();
                txtTeacher.Location = new Point(470, 115);
                txtTeacher.Size = new Size(150, 100);
                frmAnalysis.Controls.Add(txtTeacher);

                Button btnWish = new Button();
                btnWish.Text = "Построить диаграмму 'Количество пожеланий указанным преподавателем аудиторий за весь известный период'";
                btnWish.Size = new Size(150, 90);
                btnWish.Location = new Point(410, 10);
                btnWish.Click += (s, ev) => { UpdateChartByTeacherName(txtTeacher.Text); }; // Передаем значение из TextBox в метод
                frmAnalysis.Controls.Add(btnWish);

                Button btnAuditor = new Button();
                btnAuditor.Text = "Построить диаграмму 'Количество пожеланий указанной аудитории преподавателями за весь известный период'";
                btnAuditor.Size = new Size(150, 90);
                btnAuditor.Location = new Point(600, 10);
                btnAuditor.Click += (s, ev) => { UpdateChartByTeacherAuditor(txtTeacher.Text); }; // Передаем значение из TextBox в метод
                frmAnalysis.Controls.Add(btnAuditor);

                Button btnSpravka = new Button();
                btnSpravka.Text = "Справочная информация";
                btnSpravka.Size = new Size(100, 50);
                btnSpravka.Location = new Point(650, 115);
                btnSpravka.Click += new EventHandler(btnSpravka_Click);
                frmAnalysis.Controls.Add(btnSpravka);

                frmAnalysis.Show();
            }
            else
            {
                MessageBox.Show("Сначала сконвертируйте файл/файлы в формат CSV.", "Предупреждение");
            }

        }

        private void btnSpravka_Click(object sender, EventArgs e)
        {
            frmSpravka = new Form();
            frmSpravka.Text = "Справочная информация";
            frmSpravka.Size = new Size(450, 410);
            Label lblSpravka = new Label();
            lblSpravka.AutoSize = false;
            lblSpravka.Size = new Size(frmSpravka.ClientRectangle.Width, frmSpravka.ClientRectangle.Height - 40);
            lblSpravka.Location = new Point(0, 10);
            lblSpravka.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            lblSpravka.Text = File.ReadAllText("spravka.txt");

            frmSpravka.SizeChanged += (s, ev) =>
            {
                lblSpravka.Size = new Size(frmSpravka.ClientRectangle.Width, frmSpravka.ClientRectangle.Height - 40);
            };

            frmSpravka.Controls.Add(lblSpravka);
            frmSpravka.ShowDialog();


        }

        private void UpdateChartByTeacherAuditor(string teacherAuditor)
        {
            string folderPath = @"C:\Users\Екатерина\source\repos\курсовая работа 2.0\bin\Debug\csv";
            if (Directory.Exists(folderPath))
            {
                // Инициализация словаря вне цикла по файлам
                Dictionary<string, int> popularity = new Dictionary<string, int>();

                // Перебираем все файлы CSV в папке
                foreach (string filePath in Directory.GetFiles(folderPath, "*.csv"))
                {
                    List<string[]> data = new List<string[]>();

                    using (var reader = new StreamReader(filePath))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {
                            string[] parts = line.Split('!').Where(s => !string.IsNullOrWhiteSpace(s)).ToArray();
                            data.Add(parts);
                        }
                    }

                    // Обрабатываем данные из каждого файла
                    foreach (var row in data.Skip(1))
                    {
                        if (row.Length > 0 && row[row.Length - 1].Trim() == teacherAuditor) // Проверяем аудиторию
                        {
                            string teacherName = row[0].Trim(); // Получаем имя преподавателя

                            if (popularity.ContainsKey(teacherName))
                            {
                                popularity[teacherName]++;
                            }
                            else
                            {
                                popularity.Add(teacherName, 1);
                            }
                        }
                    }
                }
                // Создание и настройка диаграммы
                Chart chart = new Chart();
                chart.Size = new Size(700, 400);
                chart.Parent = frmAnalysis;
                chart.Dock = DockStyle.None;
                chart.Location = new Point(40, 200);
                chart.Titles.Add("Количество пожеланий указанной аудитории преподавателями за весь известный период"); // Добавляем название диаграммы

                chart.ChartAreas.Add("ChartArea1");
                chart.Series.Add("Кол-во");
                chart.Series["Кол-во"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column;
                chart.Series["Кол-во"].XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.String;
                chart.Series["Кол-во"].YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int32;

                // Добавление данных на диаграмму
                foreach (var item in popularity)
                {
                    chart.Series["Кол-во"].Points.AddXY(item.Key, item.Value);
                }

                // Дополнительные настройки диаграммы
                chart.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = false;
                chart.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = false;
                chart.ChartAreas["ChartArea1"].AxisX.LabelStyle.Angle = -45;
                chart.ChartAreas["ChartArea1"].AxisY.LabelStyle.Format = "{0:N0}";
                chart.Legends.Add("Legend1");
                chart.Legends["Legend1"].Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
                chart.Legends["Legend1"].Alignment = StringAlignment.Center;

                frmAnalysis.Controls.Add(chart); // Добавляем диаграмму на форму frmAnalysis

            }
            else
            {
                MessageBox.Show("Сначала сконвертируйте файл в формат CSV.", "Предупреждение");
            }
        }

        private void UpdateChartByTeacherName(string teacherName)
        {
            string folderPath = @"C:\Users\Екатерина\source\repos\курсовая работа 2.0\bin\Debug\csv";
            if (Directory.Exists(folderPath))
            {
                // Инициализация словаря вне цикла по файлам
                Dictionary<string, int> popularity = new Dictionary<string, int>();

                // Перебираем все файлы CSV в папке
                foreach (string filePath in Directory.GetFiles(folderPath, "*.csv"))
                {
                    List<string[]> data = new List<string[]>();

                    using (var reader = new StreamReader(filePath))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {
                            string[] parts = line.Split('!').Where(s => !string.IsNullOrWhiteSpace(s)).ToArray();
                            data.Add(parts);
                        }
                    }

                    // Обрабатываем данные из каждого файла
                    foreach (var row in data.Skip(1))
                    {
                        if (row.Length > 0 && row[0].Trim() == teacherName) // Проверяем фамилию преподавателя
                        {
                            string audience = row[row.Length - 1].Trim();

                            if (popularity.ContainsKey(audience))
                            {
                                popularity[audience]++;
                            }
                            else
                            {
                                popularity.Add(audience, 1);
                            }
                        }
                    }
                }

                // Создание и настройка диаграммы
                Chart chart = new Chart();
                chart.Size = new Size(700, 400);
                chart.Parent = frmAnalysis;
                chart.Dock = DockStyle.None;
                chart.Location = new Point(40, 200);
                chart.Titles.Add("Количество пожеланий указанным преподавателем аудиторий за весь известный период"); // Добавляем название диаграммы

                chart.ChartAreas.Add("ChartArea1");
                chart.Series.Add("Кол-во");
                chart.Series["Кол-во"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column;
                chart.Series["Кол-во"].XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.String;
                chart.Series["Кол-во"].YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int32;

                // Добавление данных на диаграмму
                foreach (var item in popularity)
                {
                    chart.Series["Кол-во"].Points.AddXY(item.Key, item.Value);
                }

                // Дополнительные настройки диаграммы
                chart.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = false;
                chart.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = false;
                chart.ChartAreas["ChartArea1"].AxisX.LabelStyle.Angle = -45;
                chart.ChartAreas["ChartArea1"].AxisY.LabelStyle.Format = "{0:N0}";
                chart.Legends.Add("Legend1");
                chart.Legends["Legend1"].Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
                chart.Legends["Legend1"].Alignment = StringAlignment.Center;

                frmAnalysis.Controls.Add(chart); // Добавляем диаграмму на форму frmAnalysis
            }
            else
            {
                MessageBox.Show("Сначала сконвертируйте файл в формат CSV.", "Предупреждение");
            }

        }

        private void btnPopulAll_Click(object sender, EventArgs e)
        {
            string folderPath = @"C:\Users\Екатерина\source\repos\курсовая работа 2.0\bin\Debug\csv";
            if (Directory.Exists(folderPath))
            {
                Dictionary<string, int> popularity = new Dictionary<string, int>();

                foreach (string filePath in Directory.GetFiles(folderPath, "*.csv"))
                {
                    List<string[]> data = new List<string[]>();
                    using (var reader = new StreamReader(filePath))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {
                            
                            string[] parts = line.Split('!').Where(s => !string.IsNullOrWhiteSpace(s)).ToArray();
                            data.Add(parts);
                        }
                    }

                    foreach (var row in data.Skip(1))
                    {
                        if (row.Length > 0) 
                        {
                            string audience = row[row.Length - 1].Trim();

                            if (popularity.ContainsKey(audience))
                            {
                                popularity[audience]++;
                            }
                            else
                            {
                                popularity.Add(audience, 1);
                            }
                        }
                    }
                }
                Chart chart = new Chart();
                chart.Size = new Size(700, 400);
                chart.Parent = frmAnalysis;
                chart.Dock = DockStyle.None;
                chart.Location = new Point(40, 200);
                chart.Titles.Add("Популярность заявок на аудитории всех упомянутых преподавателей"); // Добавляем название диаграммы

                chart.ChartAreas.Add("ChartArea1");
                chart.Series.Add("Кол-во");
                chart.Series["Кол-во"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column;
                chart.Series["Кол-во"].XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.String;
                chart.Series["Кол-во"].YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int32;

                foreach (var item in popularity)
                {
                    int pointIndex = chart.Series["Кол-во"].Points.AddXY(item.Key, item.Value);
                    chart.Series["Кол-во"].Points[pointIndex].IsValueShownAsLabel = false; // Скрываем значение

                    if (!string.IsNullOrEmpty(item.Key))
                    {
                        chart.Series["Кол-во"].Points[pointIndex].AxisLabel = item.Key; // Добавляем метку к каждому столбцу, если ключ не пустой
                    }
                }

                chart.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = false;
                chart.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = false;
                chart.ChartAreas["ChartArea1"].AxisX.LabelStyle.Angle = -45;
                chart.ChartAreas["ChartArea1"].AxisY.LabelStyle.Format = "{0:N0}";
                chart.Legends.Add("Legend1");
                chart.Legends["Legend1"].Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
                chart.Legends["Legend1"].Alignment = StringAlignment.Center;

                frmAnalysis.Controls.Add(chart); // Добавляем диаграмму на форму frmAnalysis
            }
            else
            {
                MessageBox.Show("Сначала сконвертируйте файл в формат CSV.", "Предупреждение");
            }

        }

        private void btnPopul_Click(object sender, EventArgs e)
        {
            string folderPath = @"C:\Users\Екатерина\source\repos\курсовая работа 2.0\bin\Debug\csv";
            if (Directory.Exists(folderPath))
            {
                Dictionary<string, int> popularity = new Dictionary<string, int>();

                foreach (string filePath in Directory.GetFiles(folderPath, "*.csv"))
                {
                    List<string[]> data = new List<string[]>();
                    using (var reader = new StreamReader(filePath))
                    {
                        string line;
                        while ((line = reader.ReadLine()) != null)
                        {
                            // Разделяем строку по "!", удаляя пустые значения
                            string[] parts = line.Split('!').Where(s => !string.IsNullOrWhiteSpace(s)).ToArray();
                            data.Add(parts);
                        }
                    }

                    var top5Aud = data.Skip(1).Take(24).ToList();

                    foreach (var row in top5Aud)
                    {
                        if (row.Length > 0) // Проверяем, есть ли хотя бы одно значение в строке
                        {
                            string audience = row[row.Length - 1].Trim(); // Получаем значение аудитории из последнего столбца

                            if (popularity.ContainsKey(audience))
                            {
                                popularity[audience]++;
                            }
                            else
                            {
                                popularity.Add(audience, 1);
                            }
                        }
                    }
                
            }

                Chart chart = new Chart();
                chart.Size = new Size(700, 400);
                chart.Parent = frmAnalysis;
                chart.Dock = DockStyle.None;
                chart.Location = new Point(40, 200);
                chart.Titles.Add("Популярность заявок на аудитории первых из упомянутых преподавателей"); // Добавляем название диаграммы

                chart.ChartAreas.Add("ChartArea1");
                chart.Series.Add("Кол-во");
                chart.Series["Кол-во"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column;
                chart.Series["Кол-во"].XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.String;
                chart.Series["Кол-во"].YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Int32;

                foreach (var item in popularity)
                {
                    int pointIndex = chart.Series["Кол-во"].Points.AddXY(item.Key, item.Value);
                    chart.Series["Кол-во"].Points[pointIndex].IsValueShownAsLabel = false; // Скрываем значение

                    if (!string.IsNullOrEmpty(item.Key))
                    {
                        chart.Series["Кол-во"].Points[pointIndex].AxisLabel = item.Key; // Добавляем метку к каждому столбцу, если ключ не пустой
                                                                                      
                        
                    }
                }

                chart.ChartAreas["ChartArea1"].AxisX.MajorGrid.Enabled = false;
                chart.ChartAreas["ChartArea1"].AxisY.MajorGrid.Enabled = false;
                chart.ChartAreas["ChartArea1"].AxisX.LabelStyle.Angle = -45;
                chart.ChartAreas["ChartArea1"].AxisY.LabelStyle.Format = "{0:N0}";
                chart.Legends.Add("Legend1");
                chart.Legends["Legend1"].Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
                chart.Legends["Legend1"].Alignment = StringAlignment.Center;

                frmAnalysis.Controls.Add(chart); // Добавляем диаграмму на форму frmAnalysis
            }
            else
            {
                MessageBox.Show("Сначала сконвертируйте файл в формат CSV.", "Предупреждение");
            }
        }
    }
}
