﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class frmFigur : Form
    {
        Graphics g;
        Random rnd = new Random();

        public frmFigur()
        {
            InitializeComponent();
        }

        private void btnDraw_Click(object sender, EventArgs e)
        {
            
            g = this.pctrbxDrow.CreateGraphics();
            
            int shapeType = (int)numericUpDown1.Value;
            int x = rnd.Next(0, this.ClientSize.Width);
            int y = rnd.Next(0, this.ClientSize.Height);

            switch (Convert.ToInt32(numericUpDown1.Value))
            {
                case 1: // Прямоугольник
                    g.DrawRectangle(Pens.Black, x, y, 50, 30);
                    break;
                case 2: // Ромб
                    Point[] points = { new Point(x, y + 15), new Point(x + 25, y), new Point(x + 50, y + 15), new Point(x + 25, y + 30) };
                    g.DrawPolygon(Pens.Black, points);
                    break;
                case 3: // Окружность
                    g.DrawEllipse(Pens.Black, x, y, 30, 30);
                    break;
                case 4: // Закрашенный круг
                    g.FillEllipse(Brushes.Black, x, y, 30, 30);
                    break;
                case 5: // Трапеция
                    Point[] trapezoidPoints = { new Point(x + 10, y), new Point(x + 40, y), new Point(x + 30, y + 30), new Point(x + 20, y + 30) };
                    g.DrawPolygon(Pens.Black, trapezoidPoints);
                    break;
                case 6: // Параллелограмм
                    Point[] parallelogramPoints = { new Point(x, y), new Point(x + 30, y), new Point(x + 50, y + 30), new Point(x + 20, y + 30) };
                    g.DrawPolygon(Pens.Black, parallelogramPoints);
                    break;
                case 7: // Прямоугольный треугольник
                    Point[] rightTrianglePoints = { new Point(x, y), new Point(x, y + 30), new Point(x + 30, y + 30) };
                    g.DrawPolygon(Pens.Black, rightTrianglePoints);
                    break;
                case 8: // Равнобедренный треугольник
                    Point[] isoscelesTrianglePoints = { new Point(x, y), new Point(x + 30, y), new Point(x + 15, y + 30) };
                    g.DrawPolygon(Pens.Black, isoscelesTrianglePoints);
                    break;
                case 9: // Центрированная надпись "Текст" в прямоугольнике
                    Rectangle textRect = new Rectangle(x, y, 100, 50);
                    g.DrawRectangle(Pens.Black, textRect);
                    StringFormat sf = new StringFormat
                    {
                        LineAlignment = StringAlignment.Center,
                        Alignment = StringAlignment.Center
                    };
                    g.DrawString("Текст", this.Font, Brushes.Black, textRect, sf);
                    break;
                case 10: // Квадрат
                    g.DrawRectangle(Pens.Black, x, y, 30, 30);
                    break;
                case 11: // Равносторонний треугольник
                    Point[] equilateralTrianglePoints = { new Point(x, y + 30), new Point(x + 30, y + 30), new Point(x + 15, y) };
                    g.DrawPolygon(Pens.Black, equilateralTrianglePoints);
                    break;
                case 12: // Эллипс
                    g.DrawEllipse(Pens.Black, x, y, 50, 30);
                    break;


            }
        }
    }
}
