﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            frmFigur form2 = new frmFigur();
            form2.Show();
        }

        private void btnSpravka_Click(object sender, EventArgs e)
        {
            frmSpravka form3 = new frmSpravka();
            form3.Show();
        }
    }
}
