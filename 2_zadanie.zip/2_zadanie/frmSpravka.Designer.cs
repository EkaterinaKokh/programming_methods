﻿namespace WindowsFormsApp2
{
    partial class frmSpravka
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSpravka));
            this.lblSpravka = new System.Windows.Forms.Label();
            this.txtbxSpravka = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblSpravka
            // 
            this.lblSpravka.AutoSize = true;
            this.lblSpravka.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblSpravka.Location = new System.Drawing.Point(-2, 9);
            this.lblSpravka.Name = "lblSpravka";
            this.lblSpravka.Size = new System.Drawing.Size(0, 26);
            this.lblSpravka.TabIndex = 0;
            // 
            // txtbxSpravka
            // 
            this.txtbxSpravka.BackColor = System.Drawing.SystemColors.Window;
            this.txtbxSpravka.Enabled = false;
            this.txtbxSpravka.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.txtbxSpravka.ForeColor = System.Drawing.SystemColors.Desktop;
            this.txtbxSpravka.Location = new System.Drawing.Point(6, 12);
            this.txtbxSpravka.Multiline = true;
            this.txtbxSpravka.Name = "txtbxSpravka";
            this.txtbxSpravka.ReadOnly = true;
            this.txtbxSpravka.Size = new System.Drawing.Size(782, 254);
            this.txtbxSpravka.TabIndex = 1;
            this.txtbxSpravka.Text = resources.GetString("txtbxSpravka.Text");
            // 
            // frmSpravka
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtbxSpravka);
            this.Controls.Add(this.lblSpravka);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Name = "frmSpravka";
            this.Text = "frmSpravka";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSpravka;
        private System.Windows.Forms.TextBox txtbxSpravka;
    }
}