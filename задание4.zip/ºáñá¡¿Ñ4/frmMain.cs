﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace задание4
{
    public partial class frmMain : Form
    {
        private ListBox lBdateInfo;
        private MonthCalendar leftCalendar;
        private MonthCalendar rightCalendar;
        private ComboBox cBdate;
        private Label lblSpravka = null;
        public frmMain()
        {
            InitializeComponent();
            this.Text = "Задание №4 выполнили: Кох Е.Е.,Папошина Л.С.,Насонова А.Н.; Номер варианта: 10; Дата выполнения: 10/05/2024";
            this.BackColor = Color.SkyBlue;



            List<DateTime> dates = new List<DateTime>();
            try
            {
                using (StreamReader sr = new StreamReader("dates.txt"))
                {
                    string line;
                    while ((line = sr.ReadLine()) != null)
                    {
                        
                        DateTime dateTime;
                        if (DateTime.TryParse(line, out dateTime))
                        {
                            dates.Add(dateTime);
                        }
                        else
                        {
                            MessageBox.Show("Некорректный формат даты в строке: " + line);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при чтении файла: " + ex.Message);
            }

            
            dates.Sort(); 

            cBdate = new ComboBox()
            {
                Location = new System.Drawing.Point(390, 10),
                Width = 150,
                DropDownStyle = ComboBoxStyle.DropDownList,
            };

            foreach (DateTime date in dates)
            {
                
                cBdate.Items.Add(date.ToString("dd.MM.yyyy"));
            }

            Controls.Add(cBdate);


            cBdate.SelectedIndexChanged += cBdate_SelectedIndexChanged;

            leftCalendar = new MonthCalendar()
            {
                Location = new System.Drawing.Point(10, 10)
            };
            leftCalendar.DateSelected += LeftCalendar_DateSelected;
            Controls.Add(leftCalendar);

            lBdateInfo = new ListBox()
            {
                Location = new System.Drawing.Point(390, 42),
                Width = 150,
            };
            Controls.Add(lBdateInfo);

            rightCalendar = new MonthCalendar()
            {
                Location = new System.Drawing.Point(200, 10),
                Enabled = false
            };
            Controls.Add(rightCalendar);

            Button btnClear = new Button()
            {
                Text = "Очистить",
                Location = new System.Drawing.Point(390, 145),
                Size = new System.Drawing.Size(100, 30),
                BackColor = Color.AliceBlue
            };
            btnClear.Click += btnClear_Click;
            Controls.Add(btnClear);


            this.KeyDown += new KeyEventHandler(Frm_KeyDown);
            this.KeyPreview = true;

        }

        private void Frm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.H)
            {
                if (lblSpravka == null)
                {
                    
                    lblSpravka = new Label();
                    lblSpravka.Text = File.ReadAllText("spravka.txt");
                    lblSpravka.AutoSize = false;
                    lblSpravka.Size = new Size(200, 300);
                    lblSpravka.Location = new Point(565, 10);
                    lblSpravka.BackColor = Color.White;
                    this.Controls.Add(lblSpravka);
                }
                else
                {
                    
                    lblSpravka.Text = "";
                }
            }

        }

        private void cBdate_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            if (cBdate.SelectedItem != null)
            {
                if (DateTime.TryParse(cBdate.SelectedItem.ToString(), out DateTime selectedDate))
                {
                    leftCalendar.SetDate(selectedDate);
                }
            }
        }


        private void btnClear_Click(object sender, EventArgs e)
        {
            lBdateInfo.Items.Clear();
        }

        private void LeftCalendar_DateSelected(object sender, DateRangeEventArgs e)
        {
            DateTime selectedDate = leftCalendar.SelectionStart;
            string season = GetSeason(selectedDate);
            string quarter = GetQuarter(selectedDate);

            lBdateInfo.Items.Clear();
            lBdateInfo.Items.Add("Сезон: " + season);
            lBdateInfo.Items.Add("Квартал: " + quarter);
        }

        private string GetSeason(DateTime selectedDate)
        {
            int month = selectedDate.Month;
            if (month >= 3 && month <= 5)
            {
                return "Весна";
            }
            else if (month >= 6 && month <= 8)
            {
                return "Лето";
            }
            else if (month >= 9 && month <= 11)
            {
                return "Осень";
            }
            else
            {
                return "Зима";
            }
        }

        private string GetQuarter(DateTime selectedDate)
        {
            int month = selectedDate.Month;
            if (month >= 1 && month <= 3)
            {
                return "1";
            }
            else if (month >= 4 && month <= 6)
            {
                return "2";
            }
            else if (month >= 7 && month <= 9)
            {
                return "3";
            }
            else
            {
                return "4";
            }
        }
    }
}